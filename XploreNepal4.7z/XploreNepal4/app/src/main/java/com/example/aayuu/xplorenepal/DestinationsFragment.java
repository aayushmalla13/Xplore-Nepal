package com.example.aayuu.xplorenepal;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import de.hdodenhof.circleimageview.CircleImageView;

public class DestinationsFragment extends Fragment {


    private StorageReference mStorageRef;
    private CircleImageView pokharaCircleImageView;
    private CircleImageView kathmanduCircleImageView;
    private CircleImageView bardiyaCircleImageView;
    private CircleImageView khaptadCircleImageView;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_destinations,container,false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Destinations");

        pokharaCircleImageView = (CircleImageView) getView().findViewById(R.id.pokharaCircleImageView);
        kathmanduCircleImageView = (CircleImageView) getView().findViewById(R.id.kathmanduCircleImageView);
        bardiyaCircleImageView = (CircleImageView) getView().findViewById(R.id.bardiyaCircleImageView);
        khaptadCircleImageView = (CircleImageView) getView().findViewById(R.id.khaptadCircleImageView);

        mStorageRef = FirebaseStorage.getInstance().getReference();

        Glide.with(this)
                .load("https://firebasestorage.googleapis.com/v0/b/xplorenepal123-9ed01.appspot.com/o/Destinations%2FpokharaCircleImageView.jpg?alt=media&token=d807b183-2e4f-47e3-b5fa-14eb861f7f76")
                .into(pokharaCircleImageView);

        Glide.with(this)
                .load("https://firebasestorage.googleapis.com/v0/b/xplorenepal123-9ed01.appspot.com/o/Destinations%2Fkathmandu.jpg?alt=media&token=a165e4c9-6a01-4cd3-888c-2722664e2f73")
                .into(kathmanduCircleImageView);

        Glide.with(this)
                .load("https://firebasestorage.googleapis.com/v0/b/xplorenepal123-9ed01.appspot.com/o/Destinations%2Fbardiya.jpg?alt=media&token=df650153-d176-46d7-8efa-63c9cc66bd34")
                .into(bardiyaCircleImageView);

        Glide.with(this)
                .load("https://firebasestorage.googleapis.com/v0/b/xplorenepal123-9ed01.appspot.com/o/Destinations%2Fkhaptadnationalpark.jpg?alt=media&token=238604a1-e459-4914-a45d-930fdd274258")
                .into(khaptadCircleImageView);

        kathmanduCircleImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getActivity(), PlacesAndActivities.class);
                startActivity(intent);


            }
        });





    }
}
