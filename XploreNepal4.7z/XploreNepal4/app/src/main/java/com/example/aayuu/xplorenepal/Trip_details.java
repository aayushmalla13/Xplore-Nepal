package com.example.aayuu.xplorenepal;

public class Trip_details {
    String user_id,user_email, trip_name,trip_date,trip_city;
    public Trip_details()
    {}

    public Trip_details(String user_id,String user_email, String trip_name, String trip_date, String trip_city) {
        this.user_id = user_id;
        this.user_email = user_email;
        this.trip_name = trip_name;
        this.trip_date = trip_date;
        this.trip_city = trip_city;
    }

    public String getUser_email() {
        return user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getTrip_name() {
        return trip_name;
    }

    public void setTrip_name(String trip_name) {
        this.trip_name = trip_name;
    }

    public String getTrip_date() {
        return trip_date;
    }

    public void setTrip_date(String trip_date) {
        this.trip_date = trip_date;
    }

    public String getTrip_city() {
        return trip_city;
    }

    public void setTrip_city(String trip_city) {
        this.trip_city = trip_city;
    }
}
