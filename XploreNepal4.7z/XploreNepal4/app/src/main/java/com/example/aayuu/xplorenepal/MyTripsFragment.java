package com.example.aayuu.xplorenepal;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseListAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MyTripsFragment extends android.support.v4.app.Fragment {
    ListView lv_trip;
    FirebaseListAdapter<Trip_details> madapter;
    DatabaseReference mref;
    FirebaseAuth mauth;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_mytrips,container,false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        lv_trip = (ListView) view.findViewById(R.id.lv_trip);
        mauth = FirebaseAuth.getInstance();
        String uid = mauth.getUid();
        mref = FirebaseDatabase.getInstance().getReference("trips");
        getActivity().setTitle("My Trips");
        view.findViewById(R.id.add_trip).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Mytrip();
                //Toast.makeText(getActivity(),"Add button clicked", Toast.LENGTH_SHORT).show();
            }
        });
        madapter = new FirebaseListAdapter<Trip_details>(getActivity(),Trip_details.class,R.layout.view_trip_layout_lv,mref) {
            @Override
            protected void populateView(View v, Trip_details model, int position) {
                TextView tripname = (TextView) v.findViewById(R.id.tv_tripname_val);
                TextView tripdate = (TextView) v.findViewById(R.id.tv_tripdate_val);
                TextView tripcity = (TextView) v.findViewById(R.id.tv_tripcity_val);
                tripname.setText(model.getTrip_name());
                tripdate.setText(model.getTrip_date());
                tripcity.setText(model.getTrip_city());

            }

        };
        lv_trip.setAdapter(madapter);

    }

    public void Mytrip() {
        Intent intent = new Intent(getActivity(), MyTripsActivity.class);
        startActivity(intent);
    }
}