package com.example.aayuu.xplorenepal;

import android.app.DatePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MyTripsActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener{
    private TextView dateselected;
    private TextView tripselected;
    EditText et_add_trip;
    DatabaseReference mref;
    FirebaseAuth mauth;
    Spinner spinner;
    Button btn_add_trip;
    String uid;
    String currentDateString;
    String city;
    ArrayAdapter<String > madapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_trips);

        Button dateselect= (Button)findViewById(R.id.selecttripdate);
        dateselected=(TextView) findViewById(R.id.pickeddate);

        tripselected= (TextView)findViewById(R.id.tripdate);
        btn_add_trip = (Button) findViewById(R.id.addtrip);
        et_add_trip = (EditText) findViewById(R.id.editText_tripp_name);
        dateselected.setVisibility(View.INVISIBLE);
        tripselected.setVisibility(View.INVISIBLE);
        dateselect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                android.support.v4.app.DialogFragment datepicker = new Datepickerfragment();
                datepicker.show(getSupportFragmentManager(),"date picker");


            }
        });
        mauth = FirebaseAuth.getInstance();
        uid = mauth.getUid();
        mref = FirebaseDatabase.getInstance().getReference("trips").child(uid);
        additemtospinner();
        btn_add_trip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tripname = et_add_trip.getText().toString();
                String date = tripselected.getText().toString();
                String email = mauth.getCurrentUser().getEmail();
                Trip_details td = new Trip_details(uid,email,tripname,currentDateString,city);
                mref.setValue(td);
            }
        });

    }

    @Override
    public void onBackPressed() {
        finish();

    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        Calendar c= Calendar.getInstance();
        c.set(Calendar.YEAR,year);
        c.set(Calendar.MONTH,month);
        c.set(Calendar.DAY_OF_MONTH,dayOfMonth);
        currentDateString = DateFormat.getDateInstance(DateFormat.FULL).format(c.getTime());
        TextView textView=(TextView) findViewById(R.id.pickeddate);
        textView.setText(currentDateString);
        dateselected.setVisibility(View.VISIBLE);
        tripselected.setVisibility(View.VISIBLE);

    }
    public void additemtospinner()
    {   spinner = (Spinner) findViewById(R.id.spinner_city);
        List<String> list = new ArrayList<String>();
        list.add("kathmandu");
        list.add("Pokhara");
        list.add("Biratnagar");
        ArrayAdapter<String> madapter = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item,list);
        madapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(madapter);
        city = spinner.getSelectedItem().toString();
    }

}

